import ProfileForm from "@/Profile/Page";
import Image from "next/image";

export default function Home() {
  return (
    <>
      <ProfileForm/>
    </>
  );
}
